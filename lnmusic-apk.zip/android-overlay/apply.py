import pathlib, shutil
base = pathlib.Path('android/app/src/main')
dst = base / 'java/com/lnmusic/app'
dst.mkdir(parents=True, exist_ok=True)
for f in ['MainActivity.java', 'PlayService.java', 'BackgroundPlayPlugin.java']:
    shutil.copy('android-overlay/' + f, dst / f)
m = base / 'AndroidManifest.xml'
t = m.read_text()
perms = ['INTERNET', 'ACCESS_NETWORK_STATE', 'CAMERA', 'RECORD_AUDIO', 'MODIFY_AUDIO_SETTINGS', 'POST_NOTIFICATIONS', 'WAKE_LOCK', 'FOREGROUND_SERVICE', 'FOREGROUND_SERVICE_MEDIA_PLAYBACK']
add = ''.join('    <uses-permission android:name="android.permission.%s" />\n' % p for p in perms if 'android.permission.%s"' % p not in t)
add += '    <uses-feature android:name="android.hardware.camera" android:required="false" />\n    <uses-feature android:name="android.hardware.microphone" android:required="false" />\n'
t = t.replace('<application', add + '    <application', 1)
t = t.replace('</application>', '        <service android:name=".PlayService" android:exported="false" android:foregroundServiceType="mediaPlayback" />\n    </application>', 1)
m.write_text(t)
shutil.copytree('android-overlay/res', base / 'res', dirs_exist_ok=True)  # ikon aplikasi (logo LNMusic, latar hitam)
print('overlay ok')
