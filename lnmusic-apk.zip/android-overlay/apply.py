import pathlib, shutil
base = pathlib.Path('android/app/src/main')
dst = base / 'java/com/lnmusic/app'
dst.mkdir(parents=True, exist_ok=True)
for f in ['MainActivity.java', 'PlayService.java', 'BackgroundPlayPlugin.java', 'MusicService.java', 'LocalMusicPlugin.java']:
    shutil.copy('android-overlay/' + f, dst / f)
manifest = base / 'AndroidManifest.xml'
t = manifest.read_text()
perms = [
    ('INTERNET', None), ('ACCESS_NETWORK_STATE', None), ('CAMERA', None),
    ('RECORD_AUDIO', None), ('MODIFY_AUDIO_SETTINGS', None), ('POST_NOTIFICATIONS', None),
    ('WAKE_LOCK', None), ('FOREGROUND_SERVICE', None),
    ('FOREGROUND_SERVICE_MEDIA_PLAYBACK', None), ('READ_EXTERNAL_STORAGE', '32'),
    ('READ_MEDIA_AUDIO', None)
]
for name, max_sdk in perms:
    marker = 'android.permission.' + name
    if marker not in t:
        extra = (' android:maxSdkVersion="' + max_sdk + '"') if max_sdk else ''
        t = t.replace('<application', '    <uses-permission android:name="' + marker + '"' + extra + ' />\n    <application', 1)
for feature in ['camera', 'microphone']:
    marker = 'android.hardware.' + feature
    if marker not in t:
        t = t.replace('<application', '    <uses-feature android:name="' + marker + '" android:required="false" />\n    <application', 1)
for name in ['PlayService', 'MusicService']:
    marker = 'android:name=".' + name + '"'
    if marker not in t:
        t = t.replace('</application>', '        <service android:name=".' + name + '" android:exported="false" android:foregroundServiceType="mediaPlayback" />\n    </application>', 1)
manifest.write_text(t)
shutil.copytree('android-overlay/res', base / 'res', dirs_exist_ok=True)
print('LNMusic Android overlay applied')
