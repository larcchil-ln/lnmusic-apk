import pathlib, shutil
base = pathlib.Path('android/app/src/main')
dst = base / 'java/com/lnmusic/app'
dst.mkdir(parents=True, exist_ok=True)
for f in ['MainActivity.java', 'PlayService.java', 'BackgroundPlayPlugin.java', 'MusicService.java', 'LocalMusicPlugin.java']:
    shutil.copy('android-overlay/' + f, dst / f)
m = base / 'AndroidManifest.xml'
t = m.read_text()
if 'MusicService' not in t:
    perms = ['INTERNET', 'ACCESS_NETWORK_STATE', 'CAMERA', 'RECORD_AUDIO', 'MODIFY_AUDIO_SETTINGS', 'POST_NOTIFICATIONS', 'WAKE_LOCK', 'FOREGROUND_SERVICE', 'FOREGROUND_SERVICE_MEDIA_PLAYBACK']
    add = ''.join('    <uses-permission android:name="android.permission.%s" />\n' % p for p in perms if 'android.permission.%s"' % p not in t)
    # akses musik di HP: Android 13+ pakai READ_MEDIA_AUDIO, di bawahnya READ_EXTERNAL_STORAGE
    add += '    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" android:maxSdkVersion="32" />\n'
    add += '    <uses-permission android:name="android.permission.READ_MEDIA_AUDIO" />\n'
    add += '    <uses-feature android:name="android.hardware.camera" android:required="false" />\n    <uses-feature android:name="android.hardware.microphone" android:required="false" />\n'
    t = t.replace('<application', add + '    <application', 1)
    svc = ''.join('        <service android:name=".%s" android:exported="false" android:foregroundServiceType="mediaPlayback" />\n' % n for n in ['PlayService', 'MusicService'])
    t = t.replace('</application>', svc + '    </application>', 1)
    m.write_text(t)
shutil.copytree('android-overlay/res', base / 'res', dirs_exist_ok=True)  # ikon aplikasi (logo LNMusic, latar hitam)
print('overlay ok')
