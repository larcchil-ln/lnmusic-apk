package com.lnmusic.app;

import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.WindowManager;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.widget.FrameLayout;
import androidx.activity.OnBackPressedCallback;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import com.getcapacitor.BridgeActivity;
import com.getcapacitor.BridgeWebChromeClient;

public class MainActivity extends BridgeActivity {
  private View customView;
  private WebChromeClient.CustomViewCallback customCb;

  @Override
  public void onCreate(Bundle savedInstanceState) {
    registerPlugin(BackgroundPlayPlugin.class);
    super.onCreate(savedInstanceState);
    final WebView wv = getBridge().getWebView();
    // Fullscreen video YouTube: layar penuh + putar otomatis ke landscape
    wv.setWebChromeClient(new BridgeWebChromeClient(getBridge()) {
      @Override
      public void onShowCustomView(View view, WebChromeClient.CustomViewCallback cb) {
        if (customView != null) { cb.onCustomViewHidden(); return; }
        customView = view; customCb = cb;
        view.setBackgroundColor(Color.BLACK);
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        cutout(true);
        ((FrameLayout) getWindow().getDecorView()).addView(view, new FrameLayout.LayoutParams(-1, -1));
        wv.setVisibility(View.GONE);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
        bars(false);
      }
      @Override
      public void onHideCustomView() { exitCustom(); }
    });
    getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
      @Override
      public void handleOnBackPressed() {
        if (customView != null) { exitCustom(); return; }
        setEnabled(false);
        getOnBackPressedDispatcher().onBackPressed();
        setEnabled(true);
      }
    });
  }

  private void exitCustom() {
    if (customView == null) return;
    ((FrameLayout) getWindow().getDecorView()).removeView(customView);
    customView = null;
    if (customCb != null) { try { customCb.onCustomViewHidden(); } catch (Exception e) {} customCb = null; }
    getBridge().getWebView().setVisibility(View.VISIBLE);
    setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
    cutout(false);
    WindowCompat.setDecorFitsSystemWindows(getWindow(), true);
    bars(true);
  }

  // Isi sampai ke area poni/kamera saat layar penuh
  private void cutout(boolean on) {
    if (Build.VERSION.SDK_INT >= 28) {
      getWindow().getAttributes().layoutInDisplayCutoutMode = on
        ? WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        : WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_DEFAULT;
      getWindow().setAttributes(getWindow().getAttributes());
    }
  }

  private void bars(boolean show) {
    WindowInsetsControllerCompat c = WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());
    if (show) c.show(WindowInsetsCompat.Type.systemBars());
    else { c.setSystemBarsBehavior(WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE); c.hide(WindowInsetsCompat.Type.systemBars()); }
  }

  // Jaga WebView tetap jalan saat layar mati / app di latar belakang
  private void keepAlive() {
    try { WebView w = getBridge().getWebView(); w.onResume(); w.resumeTimers(); } catch (Exception e) {}
  }
  @Override public void onPause() { super.onPause(); keepAlive(); }
  @Override public void onStop() { super.onStop(); keepAlive(); }
}
