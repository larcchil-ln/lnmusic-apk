package com.lnmusic.app;

import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.WindowManager;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.widget.FrameLayout;
import androidx.activity.OnBackPressedCallback;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import com.getcapacitor.BridgeActivity;
import com.getcapacitor.BridgeWebChromeClient;

public class MainActivity extends BridgeActivity {
  private View customView;
  private WebChromeClient.CustomViewCallback customCb;

  @Override
  public void onCreate(Bundle savedInstanceState) {
    registerPlugin(BackgroundPlayPlugin.class);
    registerPlugin(LocalMusicPlugin.class);
    super.onCreate(savedInstanceState);
    final WebView wv = getBridge().getWebView();
    cutout(true);
    bars(false);
    try { wv.getSettings().setMediaPlaybackRequiresUserGesture(false); } catch (Exception e) {}
    // Fullscreen video YouTube: layar penuh + putar otomatis ke landscape
    wv.setWebChromeClient(new BridgeWebChromeClient(getBridge()) {
      @Override
      public void onShowCustomView(View view, WebChromeClient.CustomViewCallback cb) {
        if (customView != null) { cb.onCustomViewHidden(); return; }
        customView = view; customCb = cb;
        view.setBackgroundColor(Color.BLACK);
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        cutout(true);
        ((FrameLayout) getWindow().getDecorView()).addView(view, new FrameLayout.LayoutParams(-1, -1));
        wv.setVisibility(View.GONE);
        bars(false);
      }
      @Override
      public void onHideCustomView() { exitCustom(); }
    });
    getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
      @Override
      public void handleOnBackPressed() {
        if (customView != null) { exitCustom(); return; }
        // Serahkan ke halaman (ln-nav.js): tutup layar -> mundur tab -> dialog keluar.
        // Aplikasi baru menutup lewat tombol "Keluar" di dialog (BackgroundPlay.exitApp).
        try {
          wv.evaluateJavascript("(function(){try{return window.lnBackPress?window.lnBackPress():'x'}catch(e){return 'x'}})()", new android.webkit.ValueCallback<String>() {
            @Override public void onReceiveValue(String v) {
              if (v == null || v.indexOf("ok") < 0) { setEnabled(false); getOnBackPressedDispatcher().onBackPressed(); setEnabled(true); }
            }
          });
        } catch (Exception e) {
          setEnabled(false); getOnBackPressedDispatcher().onBackPressed(); setEnabled(true);
        }
      }
    });
  }

  private void exitCustom() {
    if (customView == null) return;
    ((FrameLayout) getWindow().getDecorView()).removeView(customView);
    customView = null;
    if (customCb != null) { try { customCb.onCustomViewHidden(); } catch (Exception e) {} customCb = null; }
    getBridge().getWebView().setVisibility(View.VISIBLE);
    WindowCompat.setDecorFitsSystemWindows(getWindow(), true);
    bars(false);
  }

  // Isi sampai ke area poni/kamera saat layar penuh
  private void cutout(boolean on) {
    if (Build.VERSION.SDK_INT >= 28) {
      getWindow().getAttributes().layoutInDisplayCutoutMode = on
        ? WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        : WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_DEFAULT;
      getWindow().setAttributes(getWindow().getAttributes());
    }
  }

  private void bars(boolean show) {
    WindowInsetsControllerCompat c = WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());
    if (show) c.show(WindowInsetsCompat.Type.systemBars());
    else { c.setSystemBarsBehavior(WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE); c.hide(WindowInsetsCompat.Type.systemBars()); }
  }

  @Override public void onWindowFocusChanged(boolean hasFocus) { super.onWindowFocusChanged(hasFocus); if (hasFocus) bars(false); }

  // ===== Putar di latar belakang =====
  private final Handler h = new Handler(Looper.getMainLooper());
  private boolean inBg = false;
  private final Runnable pulse = new Runnable() {
    @Override public void run() {
      if (!inBg) return;
      keepAlive();
      h.postDelayed(this, 1500);
    }
  };

  // Android menandai WebView "tidak terlihat" setelah onStop (layar mati / app ditutup),
  // lalu YouTube ikut menjeda. Selama layanan putar aktif, paksa WebView tetap dianggap terlihat.
  private void keepAlive() {
    try {
      WebView w = getBridge().getWebView();
      w.onResume();
      w.resumeTimers();
      if (PlayService.running) w.dispatchWindowVisibilityChanged(View.VISIBLE);
    } catch (Exception e) {}
  }

  // Beri tahu halaman (ln-native.js) apakah app sedang di latar belakang
  private void tellPage(boolean bg) {
    try {
      final String js = "window.__lnBg=" + bg + ";window.dispatchEvent(new Event('" + (bg ? "ln-bg" : "ln-fg") + "'));";
      getBridge().getWebView().evaluateJavascript(js, null);
    } catch (Exception e) {}
  }

  @Override public void onPause() { super.onPause(); tellPage(true); keepAlive(); }
  @Override public void onStop() {
    super.onStop();
    inBg = true;
    keepAlive();
    h.removeCallbacks(pulse);
    h.postDelayed(pulse, 300); // window-visibility diubah sistem SETELAH onStop, jadi ulangi berkala
  }
  @Override public void onResume() { super.onResume(); inBg = false; h.removeCallbacks(pulse); tellPage(false); }
  @Override public void onDestroy() { h.removeCallbacks(pulse); super.onDestroy(); }
}
