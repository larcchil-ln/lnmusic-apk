package com.lnmusic.app;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;
import com.getcapacitor.JSObject;
import com.getcapacitor.PermissionState;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.annotation.PermissionCallback;

@CapacitorPlugin(name = "BackgroundPlay", permissions = { @Permission(strings = { Manifest.permission.POST_NOTIFICATIONS }, alias = "notif") })
public class BackgroundPlayPlugin extends Plugin {
  private static final String ALERT_CH = "lnmusic_alert";

  // Tombol notifikasi (Sebelumnya / Putar-Jeda / Berikutnya / Tutup) diteruskan ke halaman sebagai event "media"
  @Override
  public void load() {
    PlayService.listener = new PlayService.ActionListener() {
      @Override public void onAction(String action, long arg) {
        JSObject o = new JSObject();
        o.put("action", action);
        o.put("arg", arg);
        notifyListeners("media", o);
      }
    };
  }

  private boolean notifGranted() {
    return Build.VERSION.SDK_INT < 33 || getPermissionState("notif") == PermissionState.GRANTED;
  }

  // ===== Layanan putar latar belakang =====
  @PluginMethod
  public void start(PluginCall call) {
    if (!notifGranted()) {
      requestPermissionForAlias("notif", call, "afterPerm");
      return;
    }
    go(call);
  }

  @PermissionCallback
  private void afterPerm(PluginCall call) { go(call); }

  private void go(PluginCall call) {
    try {
      Intent i = new Intent(getContext(), PlayService.class);
      String title = call.getString("title", "LNMusic sedang memutar");
      i.putExtra("title", title);
      PlayService.stage(title, call.getString("artist", ""), call.getString("thumb", ""),
        Boolean.TRUE.equals(call.getBoolean("playing", true)), call.getLong("pos", -1L), call.getLong("dur", 0L));
      ContextCompat.startForegroundService(getContext(), i);
      call.resolve();
    } catch (Exception e) { call.reject("gagal: " + e.getMessage()); }
  }

  // Perbarui judul / artis / sampul / status putar di notifikasi (aman dipanggil dari latar belakang)
  @PluginMethod
  public void update(PluginCall call) {
    PlayService.update(call.getString("title", "LNMusic sedang memutar"), call.getString("artist", ""),
      call.getString("thumb", ""), Boolean.TRUE.equals(call.getBoolean("playing", true)),
      call.getLong("pos", -1L), call.getLong("dur", 0L));
    call.resolve();
  }

  // Tombol "Keluar" di dialog keluar aplikasi: hentikan semua pemutaran lalu tutup app
  @PluginMethod
  public void exitApp(PluginCall call) {
    try { getContext().stopService(new Intent(getContext(), PlayService.class)); } catch (Exception e) { }
    try { getContext().stopService(new Intent(getContext(), MusicService.class)); } catch (Exception e) { }
    call.resolve();
    try { if (getActivity() != null) getActivity().finishAndRemoveTask(); } catch (Exception e) { }
  }

  @PluginMethod
  public void stop(PluginCall call) {
    getContext().stopService(new Intent(getContext(), PlayService.class));
    call.resolve();
  }

  // ===== Notifikasi (mis. "Pasangan kamu sedang online") =====
  @PluginMethod
  public void checkPerm(PluginCall call) {
    JSObject r = new JSObject();
    r.put("granted", notifGranted());
    call.resolve(r);
  }

  @PluginMethod
  public void requestPerm(PluginCall call) {
    if (notifGranted()) { checkPerm(call); return; }
    requestPermissionForAlias("notif", call, "afterReq");
  }

  @PermissionCallback
  private void afterReq(PluginCall call) { checkPerm(call); }

  @PluginMethod
  public void notify(PluginCall call) {
    if (!notifGranted()) {
      requestPermissionForAlias("notif", call, "afterNotify");
      return;
    }
    show(call);
  }

  @PermissionCallback
  private void afterNotify(PluginCall call) {
    if (notifGranted()) show(call); else call.reject("izin notifikasi ditolak");
  }

  private void show(PluginCall call) {
    try {
      Context c = getContext();
      NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
      if (Build.VERSION.SDK_INT >= 26) {
        nm.createNotificationChannel(new NotificationChannel(ALERT_CH, "Notifikasi LNMusic", NotificationManager.IMPORTANCE_HIGH));
      }
      Intent open = new Intent(c, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
      PendingIntent pi = PendingIntent.getActivity(c, 1, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
      String title = call.getString("title", "LNMusic");
      String body = call.getString("body", "");
      String tag = call.getString("tag", "ln");
      android.app.Notification n = new NotificationCompat.Builder(c, ALERT_CH)
        .setContentTitle(title).setContentText(body)
        .setStyle(new NotificationCompat.BigTextStyle().bigText(body))
        .setSmallIcon(android.R.drawable.stat_notify_chat)
        .setContentIntent(pi).setAutoCancel(true)
        .setPriority(NotificationCompat.PRIORITY_HIGH)
        .setDefaults(NotificationCompat.DEFAULT_ALL).build();
      nm.notify(tag, 2, n); // tag sama = menggantikan notifikasi lama, tidak menumpuk
      call.resolve();
    } catch (Exception e) { call.reject("gagal: " + e.getMessage()); }
  }
}
