package com.lnmusic.app;

import android.Manifest;
import android.content.Intent;
import android.os.Build;
import androidx.core.content.ContextCompat;
import com.getcapacitor.PermissionState;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.annotation.PermissionCallback;

@CapacitorPlugin(name = "BackgroundPlay", permissions = { @Permission(strings = { Manifest.permission.POST_NOTIFICATIONS }, alias = "notif") })
public class BackgroundPlayPlugin extends Plugin {
  @PluginMethod
  public void start(PluginCall call) {
    if (Build.VERSION.SDK_INT >= 33 && getPermissionState("notif") != PermissionState.GRANTED) {
      requestPermissionForAlias("notif", call, "afterPerm");
      return;
    }
    go(call);
  }

  @PermissionCallback
  private void afterPerm(PluginCall call) { go(call); }

  private void go(PluginCall call) {
    try {
      Intent i = new Intent(getContext(), PlayService.class);
      i.putExtra("title", call.getString("title", "LNMusic sedang memutar"));
      ContextCompat.startForegroundService(getContext(), i);
      call.resolve();
    } catch (Exception e) { call.reject("gagal: " + e.getMessage()); }
  }

  @PluginMethod
  public void stop(PluginCall call) {
    getContext().stopService(new Intent(getContext(), PlayService.class));
    call.resolve();
  }
}
