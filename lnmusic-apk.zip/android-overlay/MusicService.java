package com.lnmusic.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.ContentUris;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.media.MediaMetadata;
import android.media.MediaPlayer;
import android.media.audiofx.BassBoost;
import android.media.audiofx.Equalizer;
import android.media.audiofx.Virtualizer;
import com.getcapacitor.JSArray;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.util.Size;
import com.getcapacitor.JSObject;
import java.util.ArrayList;
import java.util.Random;

/** Pemutar musik lokal native: jalan terus saat Home / layar mati, kontrol dari notifikasi & layar kunci. */
public class MusicService extends Service {
  public static final String A_START = "com.lnmusic.app.START";
  public static final String A_PAUSE = "com.lnmusic.app.PAUSE";
  public static final String A_RESUME = "com.lnmusic.app.RESUME";
  public static final String A_TOGGLE = "com.lnmusic.app.TOGGLE";
  public static final String A_NEXT = "com.lnmusic.app.NEXT";
  public static final String A_PREV = "com.lnmusic.app.PREV";
  public static final String A_STOP = "com.lnmusic.app.STOP";
  public static final String A_SEEK = "com.lnmusic.app.SEEK";
  public static final String A_MODE = "com.lnmusic.app.MODE";

  private static final String CH = "lnmusic_local";
  private static final int NID = 3;

  public static class Item {
    public long id, dur, albumId;
    public String title, artist, album;
    public Uri uri;
  }

  public interface StateListener { void onState(JSObject s); }

  // ===== dipakai LocalMusicPlugin =====
  public static volatile StateListener listener;
  public static volatile ArrayList<Item> queueIn = new ArrayList<>();
  public static volatile int startIndexIn = 0;
  public static volatile boolean active = false;
  private static volatile MusicService inst;
  private static final Handler MAIN = new Handler(Looper.getMainLooper());

  public static void exec(final String a, final int arg) {
    final MusicService s = inst;
    if (s == null || !active) return;
    MAIN.post(new Runnable() { @Override public void run() { s.handle(a, arg); } });
  }

  public static JSObject snapshot() {
    MusicService s = inst;
    if (s == null || !active) {
      JSObject o = new JSObject();
      o.put("active", false); o.put("playing", false);
      return o;
    }
    return s.state();
  }

  // ===== Efek audio: Equalizer / Bass Boost / Virtualizer (hanya untuk lagu offline) =====
  public static volatile boolean fxOn = false;
  public static volatile short[] fxLevels = null;      // milibel per band
  public static volatile int fxBass = 0, fxVirt = 0;   // 0..1000
  private Equalizer eq;
  private BassBoost bb;
  private Virtualizer vz;

  public static JSObject fxInfo() {
    JSObject o = new JSObject();
    MediaPlayer t = null;
    Equalizer e = null;
    try {
      t = new MediaPlayer();
      e = new Equalizer(0, t.getAudioSessionId());
      short n = e.getNumberOfBands();
      short[] r = e.getBandLevelRange();
      JSArray f = new JSArray();
      for (short i = 0; i < n; i++) f.put(e.getCenterFreq(i) / 1000);
      o.put("bands", (int) n); o.put("min", (int) r[0]); o.put("max", (int) r[1]); o.put("freqs", f); o.put("ok", true);
    } catch (Throwable x) {
      o.put("ok", false);
    } finally {
      try { if (e != null) e.release(); } catch (Throwable x) { }
      try { if (t != null) t.release(); } catch (Throwable x) { }
    }
    return o;
  }

  public static void fxSet(boolean on, short[] levels, int bass, int virt) {
    fxOn = on; fxLevels = levels; fxBass = bass; fxVirt = virt;
    final MusicService s = inst;
    if (s != null) MAIN.post(new Runnable() { @Override public void run() { s.applyFx(); } });
  }

  private void applyFx() {
    int sid = 0;
    try { if (mp != null) sid = mp.getAudioSessionId(); } catch (Exception e) { }
    if (sid == 0) return;
    try {
      if (eq == null) eq = new Equalizer(0, sid);
      eq.setEnabled(fxOn);
      short[] lv = fxLevels;
      if (fxOn && lv != null) {
        short n = eq.getNumberOfBands();
        for (short i = 0; i < n && i < lv.length; i++) eq.setBandLevel(i, lv[i]);
      }
    } catch (Throwable t) { try { if (eq != null) eq.release(); } catch (Throwable x) { } eq = null; }
    try {
      if (bb == null) bb = new BassBoost(0, sid);
      bb.setEnabled(fxOn && fxBass > 0);
      if (bb.getStrengthSupported()) bb.setStrength((short) Math.max(0, Math.min(1000, fxBass)));
    } catch (Throwable t) { try { if (bb != null) bb.release(); } catch (Throwable x) { } bb = null; }
    try {
      if (vz == null) vz = new Virtualizer(0, sid);
      vz.setEnabled(fxOn && fxVirt > 0);
      if (vz.getStrengthSupported()) vz.setStrength((short) Math.max(0, Math.min(1000, fxVirt)));
    } catch (Throwable t) { try { if (vz != null) vz.release(); } catch (Throwable x) { } vz = null; }
  }

  private void releaseFx() {
    try { if (eq != null) eq.release(); } catch (Throwable t) { } eq = null;
    try { if (bb != null) bb.release(); } catch (Throwable t) { } bb = null;
    try { if (vz != null) vz.release(); } catch (Throwable t) { } vz = null;
  }

  // ===== status =====
  private final ArrayList<Item> q = new ArrayList<>();
  private int idx = -1, repeat = 0, errStreak = 0;   // repeat: 0 mati, 1 semua, 2 satu lagu
  private boolean shuffle = false, prepared = false, wantPlay = false, pausedByFocus = false;
  private MediaPlayer mp;
  private MediaSession ms;
  private AudioManager am;
  private AudioFocusRequest afr;
  private Bitmap art;
  private final Random rnd = new Random();
  private final AudioAttributes aa = new AudioAttributes.Builder()
    .setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build();

  private final AudioManager.OnAudioFocusChangeListener fl = new AudioManager.OnAudioFocusChangeListener() {
    @Override public void onAudioFocusChange(int c) {
      switch (c) {
        case AudioManager.AUDIOFOCUS_LOSS:
          pausedByFocus = false; doPause(); break;
        case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT:
          if (playingNow()) { pausedByFocus = true; try { mp.pause(); } catch (Exception e) {} push(); }
          break;
        case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK:
          try { if (mp != null) mp.setVolume(0.2f, 0.2f); } catch (Exception e) {}
          break;
        case AudioManager.AUDIOFOCUS_GAIN:
          try { if (mp != null) mp.setVolume(1f, 1f); } catch (Exception e) {}
          if (pausedByFocus) {
            pausedByFocus = false;
            try { if (wantPlay && mp != null && prepared) mp.start(); } catch (Exception e) {}
            push();
          }
          break;
      }
    }
  };

  // cabut headset -> jeda
  private final BroadcastReceiver noisy = new BroadcastReceiver() {
    @Override public void onReceive(Context c, Intent i) {
      if (AudioManager.ACTION_AUDIO_BECOMING_NOISY.equals(i.getAction())) doPause();
    }
  };

  @Override public void onCreate() {
    super.onCreate();
    inst = this;
    am = (AudioManager) getSystemService(AUDIO_SERVICE);
    if (Build.VERSION.SDK_INT >= 26) {
      NotificationChannel ch = new NotificationChannel(CH, "Musik di HP", NotificationManager.IMPORTANCE_LOW);
      ch.setShowBadge(false);
      getSystemService(NotificationManager.class).createNotificationChannel(ch);
    }
    ms = new MediaSession(this, "LNMusic");
    ms.setCallback(new MediaSession.Callback() {
      @Override public void onPlay() { doResume(); }
      @Override public void onPause() { doPause(); }
      @Override public void onSkipToNext() { advance(false); }
      @Override public void onSkipToPrevious() { prev(); }
      @Override public void onSeekTo(long p) { seek((int) p); }
      @Override public void onStop() { quit(); }
    });
    ms.setActive(true);
    registerReceiver(noisy, new IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY));
  }

  @Override public int onStartCommand(Intent in, int flags, int startId) {
    String a = in == null ? null : in.getAction();
    if (A_START.equals(a)) {
      q.clear(); q.addAll(queueIn);
      idx = q.isEmpty() ? -1 : Math.max(0, Math.min(startIndexIn, q.size() - 1));
      active = true;
      startFg();                       // wajib langsung dipanggil setelah startForegroundService
      if (q.isEmpty()) { quit(); return START_NOT_STICKY; }
      wantPlay = true; errStreak = 0;
      playAt(idx);
    } else if (!active) {
      stopSelf();
    } else if (a != null) {
      handle(a, 0);
    }
    return START_NOT_STICKY;
  }

  void handle(String a, int arg) {
    switch (a) {
      case A_PAUSE: doPause(); break;
      case A_RESUME: doResume(); break;
      case A_TOGGLE: if (playingNow()) doPause(); else doResume(); break;
      case A_NEXT: advance(false); break;
      case A_PREV: prev(); break;
      case A_SEEK: seek(arg); break;
      case A_STOP: quit(); break;
      case A_MODE: shuffle = (arg & 4) != 0; repeat = arg & 3; push(); break;
    }
  }

  // ===== pemutaran =====
  private Item cur() { return (idx >= 0 && idx < q.size()) ? q.get(idx) : null; }

  private boolean playingNow() {
    try { return mp != null && prepared && mp.isPlaying(); } catch (Exception e) { return false; }
  }

  private void releasePlayer() {
    releaseFx();
    if (mp != null) {
      try { mp.setOnPreparedListener(null); mp.setOnCompletionListener(null); mp.setOnErrorListener(null); mp.reset(); } catch (Exception e) {}
      try { mp.release(); } catch (Exception e) {}
      mp = null;
    }
    prepared = false;
  }

  private void playAt(int i) {
    if (i < 0 || i >= q.size()) return;
    idx = i; art = null;
    releasePlayer();
    final Item it = q.get(i);
    try {
      mp = new MediaPlayer();
      mp.setAudioAttributes(aa);
      mp.setWakeMode(getApplicationContext(), PowerManager.PARTIAL_WAKE_LOCK);
      applyFx();
      mp.setDataSource(getApplicationContext(), it.uri);
      mp.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
        @Override public void onPrepared(MediaPlayer m) {
          prepared = true; errStreak = 0;
          if (wantPlay) { if (requestFocus()) { try { m.start(); } catch (Exception e) {} } else wantPlay = false; }
          push();
        }
      });
      mp.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
        @Override public void onCompletion(MediaPlayer m) { advance(true); }
      });
      mp.setOnErrorListener(new MediaPlayer.OnErrorListener() {
        @Override public boolean onError(MediaPlayer m, int what, int extra) {
          errStreak++;
          if (errStreak >= q.size()) { wantPlay = false; releasePlayer(); push(); }
          else advance(false);   // file rusak / tidak ada -> lompat ke lagu berikutnya
          return true;
        }
      });
      mp.prepareAsync();
    } catch (Exception e) {
      errStreak++;
      if (errStreak >= q.size()) { wantPlay = false; releasePlayer(); push(); }
      else MAIN.post(new Runnable() { @Override public void run() { advance(false); } });
      return;
    }
    meta(); push(); loadArt(it, i);
  }

  private void advance(boolean auto) {
    int n = q.size();
    if (n == 0) return;
    if (auto && repeat == 2) { playAt(idx); return; }
    int ni;
    if (shuffle && n > 1) { do { ni = rnd.nextInt(n); } while (ni == idx); }
    else {
      ni = idx + 1;
      if (ni >= n) { ni = 0; if (auto && repeat != 1) wantPlay = false; }   // daftar habis
    }
    if (!auto || wantPlay) wantPlay = true;
    playAt(ni);
  }

  private void prev() {
    int n = q.size();
    if (n == 0) return;
    try { if (prepared && mp != null && mp.getCurrentPosition() > 3000) { seek(0); return; } } catch (Exception e) {}
    wantPlay = true;
    playAt(idx - 1 < 0 ? n - 1 : idx - 1);
  }

  private void seek(int ms) {
    try { if (prepared && mp != null) { mp.seekTo(Math.max(0, ms)); push(); } } catch (Exception e) {}
  }

  private void doPause() {
    wantPlay = false;
    try { if (mp != null && prepared && mp.isPlaying()) mp.pause(); } catch (Exception e) {}
    abandonFocus();
    push();
  }

  private void doResume() {
    wantPlay = true;
    if (prepared && mp != null) {
      if (requestFocus()) { try { mp.start(); } catch (Exception e) {} } else wantPlay = false;
    } else if (mp == null && cur() != null) playAt(idx);
    push();
  }

  private void quit() {
    active = false;
    releasePlayer();
    abandonFocus();
    try { stopForeground(true); } catch (Exception e) {}
    StateListener l = listener;
    if (l != null) { JSObject o = new JSObject(); o.put("active", false); o.put("playing", false); l.onState(o); }
    stopSelf();
  }

  private boolean requestFocus() {
    try {
      int r;
      if (Build.VERSION.SDK_INT >= 26) {
        if (afr == null) afr = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
          .setAudioAttributes(aa).setOnAudioFocusChangeListener(fl).build();
        r = am.requestAudioFocus(afr);
      } else r = am.requestAudioFocus(fl, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN);
      return r == AudioManager.AUDIOFOCUS_REQUEST_GRANTED;
    } catch (Exception e) { return true; }
  }

  private void abandonFocus() {
    try {
      if (Build.VERSION.SDK_INT >= 26) { if (afr != null) am.abandonAudioFocusRequest(afr); }
      else am.abandonAudioFocus(fl);
    } catch (Exception e) {}
  }

  // ===== sampul album =====
  private void loadArt(final Item it, final int forIdx) {
    if (Build.VERSION.SDK_INT < 29) return;
    new Thread(new Runnable() {
      @Override public void run() {
        Bitmap b = null;
        try {
          Uri a = ContentUris.withAppendedId(Uri.parse("content://media/external/audio/albums"), it.albumId);
          b = getContentResolver().loadThumbnail(a, new Size(320, 320), null);
        } catch (Throwable e) {}
        final Bitmap fb = b;
        if (fb != null) MAIN.post(new Runnable() {
          @Override public void run() {
            if (active && idx == forIdx && forIdx < q.size() && q.get(forIdx) == it) { art = fb; meta(); push(); }
          }
        });
      }
    }).start();
  }

  // ===== sesi media, notifikasi, kabar ke halaman =====
  private void meta() {
    Item it = cur();
    if (it == null) return;
    MediaMetadata.Builder b = new MediaMetadata.Builder()
      .putString(MediaMetadata.METADATA_KEY_TITLE, it.title)
      .putString(MediaMetadata.METADATA_KEY_ARTIST, it.artist)
      .putString(MediaMetadata.METADATA_KEY_ALBUM, it.album)
      .putLong(MediaMetadata.METADATA_KEY_DURATION, it.dur);
    if (art != null) b.putBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART, art);
    ms.setMetadata(b.build());
  }

  private void session() {
    boolean pl = playingNow();
    int st = pl ? PlaybackState.STATE_PLAYING : (prepared ? PlaybackState.STATE_PAUSED : PlaybackState.STATE_BUFFERING);
    long pos = 0;
    try { if (prepared && mp != null) pos = mp.getCurrentPosition(); } catch (Exception e) {}
    long acts = PlaybackState.ACTION_PLAY | PlaybackState.ACTION_PAUSE | PlaybackState.ACTION_PLAY_PAUSE
      | PlaybackState.ACTION_SKIP_TO_NEXT | PlaybackState.ACTION_SKIP_TO_PREVIOUS
      | PlaybackState.ACTION_SEEK_TO | PlaybackState.ACTION_STOP;
    ms.setPlaybackState(new PlaybackState.Builder().setActions(acts).setState(st, pos, pl ? 1f : 0f).build());
  }

  private PendingIntent svc(String action, int code) {
    Intent i = new Intent(this, MusicService.class).setAction(action);
    return PendingIntent.getService(this, code, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
  }

  private Notification buildNotif() {
    Item it = cur();
    Intent open = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
    PendingIntent pi = PendingIntent.getActivity(this, 10, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CH) : new Notification.Builder(this);
    boolean pl = playingNow() || (wantPlay && !prepared);
    b.setSmallIcon(android.R.drawable.ic_media_play)
      .setContentTitle(it == null ? "LNMusic" : it.title)
      .setContentText(it == null ? "" : it.artist)
      .setContentIntent(pi).setOngoing(true).setOnlyAlertOnce(true).setShowWhen(false)
      .setVisibility(Notification.VISIBILITY_PUBLIC);
    if (art != null) b.setLargeIcon(art);
    b.addAction(android.R.drawable.ic_media_previous, "Sebelumnya", svc(A_PREV, 1));
    b.addAction(pl ? android.R.drawable.ic_media_pause : android.R.drawable.ic_media_play, pl ? "Jeda" : "Putar", svc(A_TOGGLE, 2));
    b.addAction(android.R.drawable.ic_media_next, "Berikutnya", svc(A_NEXT, 3));
    b.addAction(android.R.drawable.ic_menu_close_clear_cancel, "Tutup", svc(A_STOP, 4));
    b.setStyle(new Notification.MediaStyle().setMediaSession(ms.getSessionToken()).setShowActionsInCompactView(0, 1, 2));
    return b.build();
  }

  private void startFg() {
    meta(); session();
    Notification n = buildNotif();
    if (Build.VERSION.SDK_INT >= 29) startForeground(NID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
    else startForeground(NID, n);
  }

  private void push() {
    if (!active) return;
    session();
    try { ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).notify(NID, buildNotif()); } catch (Exception e) {}
    StateListener l = listener;
    if (l != null) l.onState(state());
  }

  JSObject state() {
    Item it = cur();
    JSObject o = new JSObject();
    int pos = 0, dur = it == null ? 0 : (int) it.dur;
    try { if (prepared && mp != null) { pos = mp.getCurrentPosition(); dur = mp.getDuration(); } } catch (Exception e) {}
    o.put("active", true);
    o.put("playing", playingNow());
    o.put("index", idx);
    o.put("queueLen", q.size());
    o.put("id", it == null ? -1L : it.id);
    o.put("title", it == null ? "" : it.title);
    o.put("artist", it == null ? "" : it.artist);
    o.put("album", it == null ? "" : it.album);
    o.put("pos", pos);
    o.put("dur", dur);
    o.put("shuffle", shuffle);
    o.put("repeat", repeat);
    return o;
  }

  @Override public void onTaskRemoved(Intent rootIntent) { quit(); super.onTaskRemoved(rootIntent); }

  @Override public void onDestroy() {
    active = false;
    releasePlayer();
    abandonFocus();
    try { unregisterReceiver(noisy); } catch (Exception e) {}
    try { ms.setActive(false); ms.release(); } catch (Exception e) {}
    inst = null;
    super.onDestroy();
  }

  @Override public IBinder onBind(Intent i) { return null; }
}
