package com.lnmusic.app;

import android.Manifest;
import android.content.ContentUris;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.provider.MediaStore;
import androidx.core.content.ContextCompat;
import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.PermissionState;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.annotation.PermissionCallback;
import java.util.ArrayList;
import java.util.HashMap;

@CapacitorPlugin(name = "LocalMusic", permissions = {
  @Permission(strings = { Manifest.permission.READ_EXTERNAL_STORAGE }, alias = "storage"),
  @Permission(strings = { "android.permission.READ_MEDIA_AUDIO" }, alias = "audio")
})
public class LocalMusicPlugin extends Plugin {
  private static final HashMap<Long, MusicService.Item> LIB = new HashMap<>();

  @Override
  public void load() {
    MusicService.listener = new MusicService.StateListener() {
      @Override public void onState(JSObject s) { notifyListeners("state", s); }
    };
  }

  // Android 13+ pakai READ_MEDIA_AUDIO, di bawahnya READ_EXTERNAL_STORAGE
  private String alias() { return Build.VERSION.SDK_INT >= 33 ? "audio" : "storage"; }
  private boolean ok() { return getPermissionState(alias()) == PermissionState.GRANTED; }

  @PluginMethod
  public void checkPerm(PluginCall call) {
    JSObject r = new JSObject(); r.put("granted", ok()); call.resolve(r);
  }

  @PluginMethod
  public void requestPerm(PluginCall call) {
    if (ok()) { checkPerm(call); return; }
    requestPermissionForAlias(alias(), call, "afterReq");
  }

  @PermissionCallback
  private void afterReq(PluginCall call) { checkPerm(call); }

  @PluginMethod
  public void scan(PluginCall call) {
    if (!ok()) { requestPermissionForAlias(alias(), call, "afterScan"); return; }
    doScan(call);
  }

  @PermissionCallback
  private void afterScan(PluginCall call) {
    if (ok()) doScan(call); else call.reject("izin ditolak");
  }

  private void doScan(PluginCall call) {
    try {
      Uri base = Build.VERSION.SDK_INT >= 29
        ? MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        : MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
      String[] proj = {
        MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST,
        MediaStore.Audio.Media.ALBUM, MediaStore.Audio.Media.DURATION, MediaStore.Audio.Media.ALBUM_ID
      };
      int minDur = call.getInt("minDuration", 30000);   // lewati nada dering / notifikasi
      String sel = MediaStore.Audio.Media.IS_MUSIC + " != 0 AND " + MediaStore.Audio.Media.DURATION + " >= ?";
      JSArray arr = new JSArray();
      LIB.clear();
      try (Cursor c = getContext().getContentResolver().query(base, proj, sel,
          new String[] { String.valueOf(minDur) }, MediaStore.Audio.Media.TITLE + " COLLATE NOCASE ASC")) {
        if (c != null) {
          while (c.moveToNext()) {
            MusicService.Item it = new MusicService.Item();
            it.id = c.getLong(0);
            it.title = c.getString(1) == null ? "Tanpa judul" : c.getString(1);
            String ar = c.getString(2);
            it.artist = (ar == null || ar.equals("<unknown>")) ? "Artis tidak dikenal" : ar;
            it.album = c.getString(3) == null ? "" : c.getString(3);
            it.dur = c.getLong(4);
            it.albumId = c.getLong(5);
            // Gunakan URI volume agregat yang sama dengan query agar musik dari SD Card juga bisa diputar.
            it.uri = ContentUris.withAppendedId(base, it.id);
            LIB.put(it.id, it);
            JSObject o = new JSObject();
            o.put("id", it.id); o.put("title", it.title); o.put("artist", it.artist);
            o.put("album", it.album); o.put("dur", it.dur);
            arr.put(o);
          }
        }
      }
      JSObject ret = new JSObject();
      ret.put("items", arr);
      call.resolve(ret);
    } catch (Exception e) { call.reject("gagal scan: " + e.getMessage()); }
  }

  // play({ ids:[...], index:n }) -> antrean = ids (mis. hasil pencarian), mulai dari ids[index]
  @PluginMethod
  public void play(PluginCall call) {
    JSArray ids = call.getArray("ids");
    if (ids == null) { call.reject("ids kosong"); return; }
    int index = call.getInt("index", 0);
    ArrayList<MusicService.Item> list = new ArrayList<>();
    MusicService.Item start = null;
    for (int i = 0; i < ids.length(); i++) {
      try {
        MusicService.Item it = LIB.get(ids.getLong(i));
        if (it == null) continue;
        list.add(it);
        if (i == index) start = it;
      } catch (Exception e) {}
    }
    if (list.isEmpty()) { call.reject("lagu tidak ditemukan, scan ulang"); return; }
    MusicService.queueIn = list;
    MusicService.startIndexIn = start == null ? 0 : Math.max(0, list.indexOf(start));
    try {
      ContextCompat.startForegroundService(getContext(),
        new Intent(getContext(), MusicService.class).setAction(MusicService.A_START));
      call.resolve();
    } catch (Exception e) { call.reject("gagal memulai: " + e.getMessage()); }
  }

  @PluginMethod public void pause(PluginCall call) { MusicService.exec(MusicService.A_PAUSE, 0); call.resolve(); }
  @PluginMethod public void resume(PluginCall call) { MusicService.exec(MusicService.A_RESUME, 0); call.resolve(); }
  @PluginMethod public void toggle(PluginCall call) { MusicService.exec(MusicService.A_TOGGLE, 0); call.resolve(); }
  @PluginMethod public void next(PluginCall call) { MusicService.exec(MusicService.A_NEXT, 0); call.resolve(); }
  @PluginMethod public void prev(PluginCall call) { MusicService.exec(MusicService.A_PREV, 0); call.resolve(); }
  @PluginMethod public void stop(PluginCall call) { MusicService.exec(MusicService.A_STOP, 0); call.resolve(); }

  @PluginMethod
  public void seek(PluginCall call) {
    MusicService.exec(MusicService.A_SEEK, call.getInt("ms", 0));
    call.resolve();
  }

  // setMode({ shuffle:bool, repeat:0|1|2 })
  @PluginMethod
  public void setMode(PluginCall call) {
    boolean sh = Boolean.TRUE.equals(call.getBoolean("shuffle", false));
    int rp = call.getInt("repeat", 0);
    MusicService.exec(MusicService.A_MODE, (sh ? 4 : 0) | (rp & 3));
    call.resolve();
  }

  @PluginMethod
  public void getState(PluginCall call) { call.resolve(MusicService.snapshot()); }
}
