package com.lnmusic.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaMetadata;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * Layanan putar latar belakang untuk pemutar YouTube/web.
 * Notifikasi berupa kontrol media lengkap: sampul, judul, artis, Sebelumnya / Putar-Jeda / Berikutnya / Tutup.
 * Tombolnya tidak memutar audio sendiri; ia mengirim perintah ke halaman (ln-native.js) lewat BackgroundPlayPlugin.
 */
public class PlayService extends Service {
  public static final String A_TOGGLE = "com.lnmusic.app.PS_TOGGLE";
  public static final String A_NEXT = "com.lnmusic.app.PS_NEXT";
  public static final String A_PREV = "com.lnmusic.app.PS_PREV";
  public static final String A_STOP = "com.lnmusic.app.PS_STOP";

  private static final String CH = "lnmusic_play";
  private static final int NID = 1;

  public interface ActionListener { void onAction(String action, long arg); }

  // dibaca MainActivity: true selama layanan putar aktif
  public static volatile boolean running = false;
  public static volatile ActionListener listener;
  private static volatile PlayService inst;
  private static final Handler MAIN = new Handler(Looper.getMainLooper());

  // info terakhir dari halaman (dipakai juga saat layanan baru dibuat)
  private static volatile String sTitle = "LNMusic sedang memutar", sArtist = "", sThumb = "";
  private static volatile boolean sPlaying = true;
  private static volatile long sPos = -1, sDur = 0;

  /** Simpan info lagu tanpa menyentuh notifikasi (dipanggil sebelum layanan dimulai). */
  public static void stage(String title, String artist, String thumb, boolean playing, long pos, long dur) {
    if (title != null && title.length() > 0) sTitle = title;
    sArtist = artist == null ? "" : artist;
    sThumb = thumb == null ? "" : thumb;
    sPlaying = playing; sPos = pos; sDur = dur;
  }

  /** Perbarui notifikasi & sesi media saat layanan sudah berjalan. */
  public static void update(String title, String artist, String thumb, boolean playing, long pos, long dur) {
    stage(title, artist, thumb, playing, pos, dur);
    MAIN.post(new Runnable() {
      @Override public void run() {
        PlayService s = inst;
        if (s != null && running) s.refresh();
      }
    });
  }

  private PowerManager.WakeLock wl;
  private WifiManager.WifiLock wifi;
  private MediaSession ms;
  private Bitmap art;
  private String artUrl = "";

  @Override public void onCreate() {
    super.onCreate();
    inst = this;
    if (Build.VERSION.SDK_INT >= 26) {
      NotificationChannel ch = new NotificationChannel(CH, "Pemutar LNMusic", NotificationManager.IMPORTANCE_LOW);
      ch.setShowBadge(false);
      getSystemService(NotificationManager.class).createNotificationChannel(ch);
    }
    ms = new MediaSession(this, "LNMusicPlay");
    ms.setCallback(new MediaSession.Callback() {
      @Override public void onPlay() { send("play", 0); }
      @Override public void onPause() { send("pause", 0); }
      @Override public void onSkipToNext() { send("next", 0); }
      @Override public void onSkipToPrevious() { send("prev", 0); }
      @Override public void onSeekTo(long p) { send("seek", p); }
      @Override public void onStop() { send("stop", 0); shutDown(); }
    });
    ms.setActive(true);
  }

  private void send(String a, long arg) {
    ActionListener l = listener;
    if (l != null) l.onAction(a, arg);
  }

  @Override
  public int onStartCommand(Intent in, int flags, int id) {
    String a = in == null ? null : in.getAction();
    if (a != null) {
      // tombol notifikasi ditekan
      if (!running) { stopSelf(); return START_NOT_STICKY; }
      if (A_TOGGLE.equals(a)) send("toggle", 0);
      else if (A_NEXT.equals(a)) send("next", 0);
      else if (A_PREV.equals(a)) send("prev", 0);
      else if (A_STOP.equals(a)) { send("stop", 0); shutDown(); }
      return START_NOT_STICKY;
    }

    if (in != null && in.getStringExtra("title") != null) sTitle = in.getStringExtra("title");
    startForegroundNow();
    running = true;
    if (wl == null) {
      PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
      wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "lnmusic:play");
      wl.acquire(6 * 60 * 60 * 1000L);
    }
    // Jaga Wi-Fi tetap aktif saat layar mati supaya streaming tidak putus
    if (wifi == null) {
      try {
        WifiManager wm = (WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE);
        wifi = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "lnmusic:wifi");
        wifi.acquire();
      } catch (Exception e) { wifi = null; }
    }
    loadArtIfNeeded();
    return START_NOT_STICKY; // tanpa WebView layanan ini tidak berguna, jadi jangan dihidupkan ulang sendiri
  }

  private void startForegroundNow() {
    applySession();
    Notification n = buildNotif();
    if (Build.VERSION.SDK_INT >= 29) startForeground(NID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
    else startForeground(NID, n);
  }

  private void refresh() {
    applySession();
    try { ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).notify(NID, buildNotif()); } catch (Exception e) {}
    loadArtIfNeeded();
  }

  private void shutDown() {
    running = false;
    try { stopForeground(true); } catch (Exception e) {}
    stopSelf();
  }

  // ===== sampul (diunduh di thread terpisah) =====
  private void loadArtIfNeeded() {
    final String url = sThumb;
    if (url == null || url.length() == 0 || !url.startsWith("http")) { art = null; artUrl = ""; return; }
    if (url.equals(artUrl)) return;
    artUrl = url; art = null;
    new Thread(new Runnable() {
      @Override public void run() {
        Bitmap b = null;
        HttpURLConnection c = null;
        try {
          c = (HttpURLConnection) new URL(url).openConnection();
          c.setConnectTimeout(6000); c.setReadTimeout(8000);
          InputStream is = c.getInputStream();
          BitmapFactory.Options o = new BitmapFactory.Options();
          o.inSampleSize = 1;
          b = BitmapFactory.decodeStream(is, null, o);
          is.close();
        } catch (Throwable e) {
          b = null;
        } finally { if (c != null) try { c.disconnect(); } catch (Exception e) {} }
        if (b == null) return;
        if (b.getWidth() > 640 || b.getHeight() > 640) {
          float k = Math.min(640f / b.getWidth(), 640f / b.getHeight());
          try { b = Bitmap.createScaledBitmap(b, Math.max(1, Math.round(b.getWidth() * k)), Math.max(1, Math.round(b.getHeight() * k)), true); } catch (Throwable e) {}
        }
        final Bitmap fb = b;
        MAIN.post(new Runnable() {
          @Override public void run() {
            if (running && url.equals(artUrl)) { art = fb; refresh(); }
          }
        });
      }
    }).start();
  }

  // ===== sesi media (layar kunci, headset, Bluetooth) =====
  private void applySession() {
    MediaMetadata.Builder mb = new MediaMetadata.Builder()
      .putString(MediaMetadata.METADATA_KEY_TITLE, sTitle)
      .putString(MediaMetadata.METADATA_KEY_ARTIST, sArtist)
      .putLong(MediaMetadata.METADATA_KEY_DURATION, sDur > 0 ? sDur : -1);
    if (art != null) mb.putBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART, art);
    ms.setMetadata(mb.build());
    long acts = PlaybackState.ACTION_PLAY | PlaybackState.ACTION_PAUSE | PlaybackState.ACTION_PLAY_PAUSE
      | PlaybackState.ACTION_SKIP_TO_NEXT | PlaybackState.ACTION_SKIP_TO_PREVIOUS | PlaybackState.ACTION_STOP;
    if (sDur > 0) acts |= PlaybackState.ACTION_SEEK_TO;
    ms.setPlaybackState(new PlaybackState.Builder().setActions(acts)
      .setState(sPlaying ? PlaybackState.STATE_PLAYING : PlaybackState.STATE_PAUSED,
        sPos >= 0 ? sPos : PlaybackState.PLAYBACK_POSITION_UNKNOWN, sPlaying ? 1f : 0f).build());
  }

  private PendingIntent act(String action, int code) {
    Intent i = new Intent(this, PlayService.class).setAction(action);
    return PendingIntent.getService(this, code, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
  }

  private Notification buildNotif() {
    Intent open = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
    PendingIntent pi = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CH) : new Notification.Builder(this);
    b.setSmallIcon(android.R.drawable.ic_media_play)
      .setContentTitle(sTitle)
      .setContentText(sArtist.length() > 0 ? sArtist : "LNMusic")
      .setContentIntent(pi).setOngoing(true).setOnlyAlertOnce(true).setShowWhen(false)
      .setVisibility(Notification.VISIBILITY_PUBLIC);
    if (art != null) b.setLargeIcon(art);
    b.addAction(android.R.drawable.ic_media_previous, "Sebelumnya", act(A_PREV, 21));
    b.addAction(sPlaying ? android.R.drawable.ic_media_pause : android.R.drawable.ic_media_play,
      sPlaying ? "Jeda" : "Putar", act(A_TOGGLE, 22));
    b.addAction(android.R.drawable.ic_media_next, "Berikutnya", act(A_NEXT, 23));
    b.addAction(android.R.drawable.ic_menu_close_clear_cancel, "Tutup", act(A_STOP, 24));
    b.setStyle(new Notification.MediaStyle().setMediaSession(ms.getSessionToken()).setShowActionsInCompactView(0, 1, 2));
    return b.build();
  }

  @Override public void onTaskRemoved(Intent rootIntent) { running = false; stopSelf(); super.onTaskRemoved(rootIntent); }

  @Override public void onDestroy() {
    running = false;
    if (wl != null && wl.isHeld()) wl.release(); wl = null;
    if (wifi != null && wifi.isHeld()) wifi.release(); wifi = null;
    try { ms.setActive(false); ms.release(); } catch (Exception e) {}
    inst = null;
    super.onDestroy();
  }
  @Override public IBinder onBind(Intent i) { return null; }
}
