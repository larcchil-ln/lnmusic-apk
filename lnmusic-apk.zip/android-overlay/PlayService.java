package com.lnmusic.app;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;
import androidx.core.app.NotificationCompat;

public class PlayService extends Service {
  private static final String CH = "lnmusic_play";
  private PowerManager.WakeLock wl;

  @Override
  public int onStartCommand(Intent in, int flags, int id) {
    if (Build.VERSION.SDK_INT >= 26) {
      NotificationChannel ch = new NotificationChannel(CH, "Pemutar LNMusic", NotificationManager.IMPORTANCE_LOW);
      getSystemService(NotificationManager.class).createNotificationChannel(ch);
    }
    Intent open = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
    PendingIntent pi = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    String title = (in != null && in.getStringExtra("title") != null) ? in.getStringExtra("title") : "LNMusic sedang memutar";
    android.app.Notification n = new NotificationCompat.Builder(this, CH)
      .setContentTitle(title).setContentText("Ketuk untuk kembali ke LNMusic")
      .setSmallIcon(android.R.drawable.ic_media_play).setContentIntent(pi).setOngoing(true).build();
    if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
    else startForeground(1, n);
    if (wl == null) {
      PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
      wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "lnmusic:play");
      wl.acquire(6 * 60 * 60 * 1000L);
    }
    return START_STICKY;
  }

  @Override public void onDestroy() { if (wl != null && wl.isHeld()) wl.release(); wl = null; super.onDestroy(); }
  @Override public IBinder onBind(Intent i) { return null; }
}
